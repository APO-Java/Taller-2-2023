package consola;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Hashtable;

import modulo.Combo;
import modulo.Ingrediente;
import modulo.Pedido;
import modulo.Producto;
import modulo.ProductoAjustado;
import modulo.Restaurante;

public class Aplicacion {
	private static Restaurante restaurante = new Restaurante();
	
	private static Hashtable<String, ProductoAjustado> productosAjustados = new Hashtable<String,ProductoAjustado>();
	
	public static void main(String[] args) throws IOException {
		
		File archivoIngredientes= new File("data/ingredientes.txt");
		File archivoMenu = new File("data/menu.txt");
		File archivoCombos = new File("data/combos.txt");
		restaurante.cargarInformacionRestaurante(archivoIngredientes,archivoMenu,archivoCombos);
		
		boolean terminar = false;
		while(!terminar) {
			mostrarOpcionesDisponibles();
			System.out.print("\nPor favor digite la opción que desee realizar: ");
			BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
			String input = br.readLine();
			if(input == null) {
				System.out.println("\nLa entrada no puede estar vacia.");
			}
			else {
				try {
					terminar = ejecutarOpcion(Integer.parseInt(input));
					System.out.print("\nPresione 'Enter' para continuar.");
					BufferedReader brStop = new BufferedReader(new InputStreamReader(System.in));
					try {
						String inputStop = brStop.readLine();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				} catch (NumberFormatException nfe ) {
					System.out.println("La entrada debe ser un valor numérico.");
				}
				
			}
		}
	}
	
	private static void mostrarOpcionesDisponibles() {
		System.out.println("\n\tOpciones disponibles");
		System.out.println("1) Mostrar Menu");
		System.out.println("2) Iniciar un nuevo pedido");
		System.out.println("3) Ajustar pedido (agregar un elemento, adicionar/eliminar ingredientes)");
		System.out.println("4) Cerrar un perdido y guardar la factura");
		System.out.println("5) Consultar la informacion de un pedido dado su ID");
		System.out.println("6) Cerrar aplicacion");
	}
	
	private static void mostrarMenuProductos() {
		System.out.print("\n\t\tProductos Base\n\n");
		for (int i = 0; i < restaurante.getMenuBase().size(); i++) {
			int pos = i +1;
			System.out.println(" *"+(pos)+ " "+ restaurante.getMenuBase().get(i).generarTextoFactura());
		}
	}
	
	private static void mostrarMenuCombos() {
		System.out.print("\n\t\tCombos\n\n");
		for (int i = 0; i < restaurante.getCombos().size(); i++) {
			Combo combo = restaurante.getCombos().get(i);
			System.out.println(i+1 + " "+ combo.generarTextoFactura());
			System.out.println("\tItems en el Combo "+ combo.getNombre());
			for (int j = 0; j < combo.getItemsCombo().size(); j++) {
				System.out.println("\t- "+combo.getItemsCombo().get(j).getNombre());
			}
		}
	}
	
	private static void mostrarMenuIngredientes() {
		System.out.print("\n\t\tIngredientes para adicionar (o eliminar)\n\n");
		for (int i = 0; i < restaurante.getIngredientes().size(); i++) {
			int pos = i +1;
			Ingrediente ingrediente = restaurante.getIngredientes().get(i);
			System.out.println(" *"+pos + " "+ ingrediente.getNombre() + " $"+ingrediente.getCostoAdicional());
		}
	}
	
	public static void mostrarMenu() {
		System.out.println("\n\t\tMenú\n\n"+"><".repeat(25));
		mostrarMenuProductos();
		System.out.println("\n"+"><".repeat(25));
		mostrarMenuIngredientes();
		System.out.println("\n" + "><".repeat(25));
		mostrarMenuCombos();
		System.out.println();
	}
	
	public static void iniciarNuevoPedido() {
		boolean opcionValida = false;
		String nombreCliente = "";
		while(!opcionValida) {
			System.out.print("\nPor favor, ingrese el nombre del cliente: ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			try {
				nombreCliente = br.readLine();
				opcionValida = true;
			} catch (IOException e) {
				System.out.print("\nLa entrada no puede estar vacía.");
			}
		}
		
		opcionValida = false;
		String direccionCliente = "";
		while(!opcionValida) {
			System.out.print("\nPor favor, ingrese la direccion del cliente: ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			try {
				direccionCliente = br.readLine();
				opcionValida = true;
			} catch (IOException e) {
				System.out.print("\nLa entrada no puede estar vacía.");
			}
		}
		restaurante.iniciarPedido(nombreCliente,direccionCliente);
		System.out.println("Se ha iniciado un nuevo pedido con id " + restaurante.getPedidoEnCurso().getIdPedido()+".");
	}
	
	public static void agregarElementoPedido(int tipoElemento, int numeroElemento) {
		if (tipoElemento == 1) {
			Pedido pedido = restaurante.getPedidoEnCurso();
			pedido.agregarProducto(restaurante.getMenuBase().get(numeroElemento));
		}
		else if (tipoElemento == 2) {
			Pedido pedido = restaurante.getPedidoEnCurso();
			pedido.agregarProducto(restaurante.getCombos().get(numeroElemento));
		}
		
	}
	
	public static boolean agregarEliminarIngrediente(String nombreElemento, int numeroIngrediente, int adicionarEliminar) {
		Pedido pedido = restaurante.getPedidoEnCurso();
		boolean encontrado = false;
		int i = 0;
		while (!encontrado && i < pedido.getItemsPedido().size()) {
			if (pedido.getItemsPedido().get(i).getNombre().equals(nombreElemento)) {
				encontrado = true;
			}
			else {
				i++;
			}
		}
		boolean encontradoProductoBase = false;
		int j = 0;
		while (!encontradoProductoBase) {
			if (restaurante.getMenuBase().get(j).getNombre().equals(nombreElemento)) {
				encontradoProductoBase = true;
			}
			else {
			j++;
			}
		}
		ProductoAjustado producto;
		String nombreProducto = restaurante.getMenuBase().get(j).getNombre();
		if (productosAjustados.containsKey(nombreProducto)) {
			producto = productosAjustados.get(nombreProducto);
		}
		else {
			producto = new ProductoAjustado(restaurante.getMenuBase().get(j));
		}
		if (adicionarEliminar == 0) {
		producto.agregarIngrediente(restaurante.getIngredientes().get(numeroIngrediente));
		}
		else {
		producto.eliminarIngrediente(restaurante.getIngredientes().get(numeroIngrediente));	
		}
		
		if (productosAjustados.containsKey(nombreProducto)) {
			productosAjustados.replace(nombreProducto,producto);
		}
		else {
			productosAjustados.put(nombreProducto, producto);
		}
		pedido.getItemsPedido().set(i,producto);
		return encontrado;
	}
	
	//Esta función se encarga de agregar elementos a una orden o ajustar ingredientes en elementos ya añadidos a la orden
	//Para añadir o eliminar un ingrediente, se asume que los elementos sobre los cuales se añadirá un ingrediente
	//son de tipo ProductoMenu y no un Combo
	public static void ajustarMenu() {
		int opcionAjuste = 0;
		boolean valido = false;
		while (!valido) {
			System.out.print("\n\tOpciones de Ajuste \n1 - Adicionar un elemento al pedido\n2 - Adicionar o eliminar un ingrediente");
			System.out.print("\nPor favor, digite la opción que corresponde a la manera como desea ajustar el menu: ");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			try {
				String input = br.readLine();
				try {
			       opcionAjuste = Integer.parseInt(input);
			        if (opcionAjuste > 2 || opcionAjuste < 1) {
			        	System.out.print("\nEl valor debe 1 o 2.");
			        }
			        else {
			        	valido = true;
			        }
			    } catch (NumberFormatException nfe) {
			    	System.out.print("\nLa entrada debe ser un número (1 o 2).");
			    }
				} catch (IOException e) {
					System.out.print("\nLa entrada no puede estar vacía.");
				}
		}
		if (opcionAjuste == 1) {
			System.out.print("\n\tOpciones \n1 - Producto del menú\n2 - Combo");
			boolean opcionValida = false;
			String tipoElemento = "";
			while(!opcionValida) {
				System.out.print("\nPor favor, digite el tipo de elemento del menú que desea añadir: ");
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				try {
				tipoElemento = br.readLine();
				if (tipoElemento.equals("1") || tipoElemento.equals("2")) {
					opcionValida = true;
				}
				else {
					System.out.print("\nLa entrada debe ser un número (1 o 2).");
				}
				} catch (IOException e) {
					System.out.print("\nLa entrada no puede estar vacía.");
				}
			}
			opcionValida = false;
			int numeroElemento = 0;
			while(!opcionValida) {
				int maximoValor = 0;
				if (Integer.parseInt(tipoElemento)==1) {
					mostrarMenuProductos();
					maximoValor = restaurante.getMenuBase().size()+1;
				}
				else {
					mostrarMenuCombos();
					maximoValor = restaurante.getCombos().size()+1;
				}
				System.out.print("\nPor favor, digite el número del elemento del menú que desea añadir: ");
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				try {
					String input = br.readLine();
					try {
				        numeroElemento = Integer.parseInt(input);
				        opcionValida = true;
				    } catch (NumberFormatException nfe) {
				    	System.out.print("\nLa entrada debe ser un número entre 1 y "+maximoValor +".");
				    }
					} catch (IOException e) {
						System.out.print("\nLa entrada no puede estar vacía.");
					}
			}
			agregarElementoPedido(Integer.parseInt(tipoElemento),numeroElemento-1);
			System.out.println("\nSe ha agregado el nuevo elemento al menú.");
		}
		else {
			ArrayList<Producto> productosPedido = restaurante.getPedidoEnCurso().getItemsPedido();
			if (productosPedido.size() == 0) {
				System.out.println("\nAún no se han registrado productos en el pedido.");
			}
			else {
				System.out.println("\nEstos son los productos hasta el momento en su pedido.");
				boolean hayProductos = false;
				ArrayList<String> productos = new ArrayList<String>();
				for (int i = 0; i < productosPedido.size(); i++) {
					String nombreProducto = productosPedido.get(i).getNombre();
					System.out.println("+ "+nombreProducto);
					if (!nombreProducto.contains("combo")) {
						hayProductos = true;
						productos.add(nombreProducto);
					}
				}
				if (!hayProductos) {
					System.out.println("Sin embargo, no tiene productos ajustables, por ende, no puede modificar ingredientes.");
				}
				else {
				boolean opcionValida = false;
				int numeroElemento = 0;
				System.out.println("Estos son los productos sobre los que puede realizar modificaciones en su pedido: ");
				for (int i = 0; i < productos.size(); i++) {
					int pos = i+1;
					System.out.println("\t"+pos+" "+productos.get(i));
				}
				while(!opcionValida) {
				System.out.print("\nPor favor, digite el número del elemento del menú en el que desea ajustar un ingrediente: ");
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				try {
					try {
						numeroElemento = Integer.parseInt(br.readLine());
						} catch (NumberFormatException nfe) {
						System.out.println("\nLa entrada debe ser un valor numérico.");
					}
				if (numeroElemento > productos.size() || numeroElemento < 1) {
					System.out.println("Debe seleccionar un valor válido.");
				}
				else {
					opcionValida = true;
				}
				} catch (IOException e) {
					System.out.print("\nLa entrada no puede estar vacía.");
				}
				}
				String nombreElemento = productos.get(numeroElemento-1);
				opcionValida = false;
				numeroElemento = 0;
				int maximoValor = restaurante.getIngredientes().size()+1;
				mostrarMenuIngredientes();
				while(!opcionValida) {
					System.out.print("\nPor favor, digite el número del ingrediente que desea añadir o eliminar: ");
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					try {
						String input = br.readLine();
						try {
					        numeroElemento = Integer.parseInt(input);
					        opcionValida = true;
					    } catch (NumberFormatException nfe) {
					    	System.out.print("\nLa entrada debe ser un número entre 1 y "+maximoValor +".");
					    }
						} catch (IOException e) {
							System.out.print("\nLa entrada no puede estar vacía.");
						}
				}
				opcionValida = false;
				int agregarEliminar = 0;
				while(!opcionValida) {
					System.out.print("\n\tOpciones \n0 - Añadir ingrediente\n1 - Eliminar ingrediente");
					System.out.print("\nPor favor, digite la opción que corresponde a aquello que desea hacer con el ingrediente: ");
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
					try {
						String input = br.readLine();
						try {
					       agregarEliminar = Integer.parseInt(input);
					        if (agregarEliminar > 1 || agregarEliminar < 0) {
					        	System.out.print("\nEl valor debe 0 o 1.");
					        }
					        else {
					        	opcionValida = true;
					        }
					    } catch (NumberFormatException nfe) {
					    	System.out.print("\nLa entrada debe ser un número (0 o 1).");
					    }
						} catch (IOException e) {
							System.out.print("\nLa entrada no puede estar vacía.");
						}
				}
				
				boolean agregadoEliminado = agregarEliminarIngrediente(nombreElemento,numeroElemento-1,agregarEliminar);
				if (!agregadoEliminado) {
					System.out.print("\nNo se ha podido encontrar el elemento del menú que ha ingresado por parámetro.");
				}
				else {
					if (agregarEliminar == 0) {
						System.out.println("\nSe ha agregado el ingrediente a "+ nombreElemento+".");
					}
					else {
						System.out.println("\nSe ha eliminado el ingrediente de "+ nombreElemento+".");
					}
				}
			}
			}
		}
	}
	
	public static void cerrarPedidoGuardarFactura() {
		restaurante.cerrarYGuardarPedido();
		System.out.println("\nSe ha cerrado el pedido y se ha guardado la factura.");
	}
	
	public static void consultarPedidoPorId() throws IOException {
		int maximoValor = restaurante.getPedidoEnCurso().getNumeroPedidos();
		if (maximoValor == 0) {
			System.out.print("\nAún no se han completado pedidos.");
		}
		else if (restaurante.getPedidoEnCurso().getPedidoAbierto()) {
			System.out.print("\nEl pedido actual aún se encuentra abierto.\nPor favor espere a que se cierre para solicitar consultar un pedido.");
		}
		else {
			System.out.print("\nSe consultará la información de un pedido basado en su id.");
			boolean opcionValida = false;
			int idPedido = 0;
			while(!opcionValida) {
				System.out.print("\nPor favor digite el id del pedido: ");
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				try {
					String input = br.readLine();
					try {
				        idPedido = Integer.parseInt(input);
				        if (maximoValor == 1 && idPedido != 1) { 
				        	System.out.print("\nEl número debe ser 1.");
				        }
				        else if (idPedido > maximoValor || idPedido < 1) { 
				        	System.out.print("\nEl número debe encontrarse entre 1 y "+maximoValor +".");
				        }
				        else {
				        	opcionValida = true;
				        }
				    } catch (NumberFormatException nfe) {
				    	if (maximoValor == 1) {
				    		System.out.print("\nLa entrada debe ser un número entre 1.");
				    	}
				    	else {
				    		System.out.print("\nLa entrada debe ser un número entre 1 y "+maximoValor +".");
				    	}
				    }
					} catch (IOException e) {
						System.out.print("\nLa entrada no puede estar vacía.");
					}
			}
			System.out.println("\nInformación del Pedido "+idPedido);
			FileReader file;
			try {
				file = new FileReader("FacturaPedido"+ idPedido+ ".txt");
				BufferedReader br = new BufferedReader(file);
				String line = br.readLine();
				while (!(line == null)) {
					System.out.println(line);
					line = br.readLine();
				}
				br.close();
				System.out.println("\nSe ha presentado la información del pedido.");
			} catch (FileNotFoundException e) {
				System.out.println("No ha sido posible localizar el archivo.");
			}
		}
	}
	
	public static boolean ejecutarOpcion(int opcionSeleccionada) throws IOException {
		boolean terminar = false;
		if (opcionSeleccionada == 1) {
			mostrarMenu();
		}
		else if (opcionSeleccionada == 2) {
			iniciarNuevoPedido();
		}
		else if (restaurante.getPedidoEnCurso()==null) {
			System.out.println("\nDebe iniciar un nuevo pedido antes de continuar.");
		}
		else if (opcionSeleccionada == 3) {
			if (restaurante.getPedidoEnCurso().getPedidoAbierto()) {
				ajustarMenu();
			}
			else {
				System.out.println("\nEl pedido se ha cerrado. Para poder hacer esta operación, abra un nuevo pedido.");
			}
		}
		else if (opcionSeleccionada == 4) {
			cerrarPedidoGuardarFactura();
		}
		else if (opcionSeleccionada == 5) {
			consultarPedidoPorId();
		}
		else if (opcionSeleccionada == 6) {
			terminar = true;
		}
		else {
			System.out.println("Debe seleccionar una opción válida.");
		}
		return terminar;
	}
}
