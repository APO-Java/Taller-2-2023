package modulo;

import java.util.ArrayList;

public class Combo implements Producto {
	private double descuento;
	
	private String nombreCombo;
	
	private ArrayList<ProductoMenu> itemsCombo = new ArrayList<ProductoMenu>();
	
	public Combo(String nombre, double descuento) {
		this.descuento = descuento;
		nombreCombo = nombre;
	}
	
	public String getNombre() {
		return nombreCombo;
	}
	
	public void agregarItemCombo(ProductoMenu itemCombo) {
		itemsCombo.add(itemCombo);
	}
	
	public int getPrecio() {
		int precio = 0;
		for (int i = 0; i < itemsCombo.size(); i++) {
			precio += itemsCombo.get(i).getPrecio();
		}
		precio = (int) (precio*(1-descuento));
		return precio;
	}
	
	public ArrayList<ProductoMenu> getItemsCombo() {
		return itemsCombo;
	}
	
	public String generarTextoFactura() {
		return nombreCombo + "  $" + getPrecio();
	}
}
