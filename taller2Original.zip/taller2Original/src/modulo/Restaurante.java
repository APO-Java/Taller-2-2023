package modulo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;

public class Restaurante {
	private Hashtable<Integer,Pedido> pedidos = new Hashtable<Integer,Pedido>();
	
	private Pedido pedidoEnCurso;
	
	private ArrayList<ProductoMenu> menuBase = new ArrayList<ProductoMenu>();
	
	private ArrayList<Ingrediente> ingredientes = new ArrayList<Ingrediente>();
	
	private ArrayList<Combo> combos = new ArrayList<Combo>();
	
	public Restaurante() {
	}
	
	public void iniciarPedido(String nombreCliente, String direccionCliente) {
		pedidoEnCurso = new Pedido(nombreCliente,direccionCliente);
	}
	
	public void cerrarYGuardarPedido() {
		pedidos.put(pedidoEnCurso.getIdPedido(), pedidoEnCurso);
		File archivo = new File("FacturaPedido"+pedidoEnCurso.getIdPedido()+".txt");
		pedidoEnCurso.guardarFactura(archivo);
		pedidoEnCurso.modificarPedidoAbierto(false);
	}
	
	public Pedido getPedidoEnCurso() {
		return pedidoEnCurso;
	}
	
	public ArrayList<ProductoMenu> getMenuBase() {
		return menuBase;
	}
	
	public ArrayList<Ingrediente> getIngredientes() {
		return ingredientes;
	}
	
	public ArrayList<Combo> getCombos() {
		return combos;
	}
	
	public void cargarInformacionRestaurante(File archivoIngredientes, File archivoMenu, 
			File archivoCombos) {
		try {
			cargarIngredientes(archivoIngredientes);
			cargarMenu(archivoMenu);
			cargarCombos(archivoCombos);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void cargarIngredientes(File archivoIngredientes) throws IOException {
		FileReader file = new FileReader("./data/ingredientes.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			Ingrediente ingrediente = new Ingrediente(arrayCadenas[0],Integer.parseInt(arrayCadenas[1]));
			ingredientes.add(ingrediente);
			line = br.readLine();
		}
		br.close();
	}
	
	private void cargarMenu(File archivoMenu) throws IOException {
		FileReader file = new FileReader("./data/menu.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			ProductoMenu producto = new ProductoMenu(arrayCadenas[0],Integer.parseInt(arrayCadenas[1]));
			menuBase.add(producto);
			line = br.readLine();
		}
		br.close();
	}
	
	private void cargarCombos(File archivoCombos) throws IOException {
		FileReader file = new FileReader("./data/combos.txt");
		BufferedReader br = new BufferedReader(file);
		String line = br.readLine();
		while (line != null) {
			var arrayCadenas = line.split(";");
			Combo combo = new Combo(arrayCadenas[0],Double.valueOf(arrayCadenas[1].replace("%", ""))/100);
			boolean encontradosTodos = false;
			int i = 0;
			int productosEncontrados = 0;
			while(!encontradosTodos && i < menuBase.size()) {
				int j = 2;
				boolean encontrado = false;
				while (j < arrayCadenas.length && !encontrado) {
					if(menuBase.get(i).getNombre().equals(arrayCadenas[j])) {
						combo.agregarItemCombo(menuBase.get(i));
						productosEncontrados++;
						encontrado = true;
					}
					j++;
				}
				if(productosEncontrados == arrayCadenas.length-2) {
					encontradosTodos = true;
				}
				i++;
			}
			combos.add(combo);
			line = br.readLine();
		}
		br.close();
	}
}
