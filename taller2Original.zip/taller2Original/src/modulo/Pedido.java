package modulo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Pedido {
	//Atributos 
	private static int numeroPedidos;
	
	private int idPedido;
	
	private boolean pedidoAbierto;
	
	private String nombreCliente;
	
	private String direccionCliente;
	
	private ArrayList<Producto> itemsPedido = new ArrayList<Producto>();
	
	//Métodos
	public Pedido(String nombreCliente, String direccionCliente) {
		numeroPedidos++;
		idPedido = numeroPedidos;
		this.nombreCliente = nombreCliente;
		this.direccionCliente = direccionCliente;
		pedidoAbierto = true;
	}
	
	public boolean getPedidoAbierto() {
		return pedidoAbierto;
	}
	
	public void modificarPedidoAbierto(boolean pedidoAbierto) {
		this.pedidoAbierto = pedidoAbierto;
	}
	
	public int getNumeroPedidos() {
		return numeroPedidos;
	}
	
	public int getIdPedido() {
		return idPedido;
	}
	
	public void agregarProducto(Producto nuevoItem) {
		itemsPedido.add(nuevoItem);
	}
	
	public ArrayList<Producto> getItemsPedido() {
		return itemsPedido;
	}
	
	private int getPrecioNetoPedido() {
		int precioNeto = 0;
		for (int i = 0; i < itemsPedido.size(); i++) {
			precioNeto += itemsPedido.get(i).getPrecio();
		}
		return precioNeto;
	}
	
	private int getPrecioIvaPedido() {
		int precioIva = 0;
		for (int i = 0; i < itemsPedido.size(); i++) {
			precioIva += itemsPedido.get(i).getPrecio()*0.19;
		}
		return precioIva;
	}
	
	private int getPrecioTotalPedido() {
		return getPrecioNetoPedido() + getPrecioIvaPedido();
	}
	
	private String generarTextoFactura() {
		String factura = "=".repeat(20)+"\nidPedido: " + idPedido + 
				"\nDatos cliente:\nNombre: " + nombreCliente + "\nDireccion: " + direccionCliente+
				"\n"+"=".repeat(20) + "\nLos items en el pedido son:";
		for (int i = 0; i < itemsPedido.size(); i++) {
			factura += "\n"+i + " " + itemsPedido.get(i).generarTextoFactura();
		}
		factura +="\n"+"=".repeat(20)+"\nSubtotal: " + getPrecioNetoPedido() +
				"\nIVA (19%): " + getPrecioIvaPedido() + 
				"\n"+"=".repeat(20)+"\nTotal: " + getPrecioTotalPedido()+
				"\n";
		return factura;
	}
	
	public void guardarFactura(File archivo) {
			BufferedWriter writer;
			try {
				writer = new BufferedWriter(new FileWriter(archivo.getName()));
				writer.write(generarTextoFactura());
				writer.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	
}
