package modulo;

public interface Producto {
	
	public int getPrecio();
	
	public String getNombre();
	
	public String generarTextoFactura();
	
}
