package modulo;

import java.util.ArrayList;

public class ProductoAjustado extends ProductoMenu implements Producto {
	
	private ProductoMenu base;
	
	private ArrayList<Ingrediente> agregados = new ArrayList<Ingrediente>();
	
	private ArrayList<Ingrediente> eliminados = new ArrayList<Ingrediente>();
	
	public ProductoAjustado(ProductoMenu base) {
		super(base.getNombre(),base.getPrecio());
		this.base = base;
	}
	
	public String generarTextoFactura() {
		int precio = 0;
		String factura = nombre;
		precio += precioBase;
		if (agregados.size() > 0) {
			factura +=" con ";
			for (int i = 0; i < agregados.size(); i++) {
				factura += agregados.get(i).getNombre();
				precio += agregados.get(i).getCostoAdicional();
				if (i+1 < agregados.size()) {
					factura += ", ";
				}
			}
		}
		if (agregados.size()>0 && eliminados.size()>0) {
			factura += "; ";
		}
		if (eliminados.size() > 0) {
			factura +=" sin ";
			for (int i = 0; i < eliminados.size(); i++) {
				factura += eliminados.get(i).getNombre();
				if (i+1 < eliminados.size()) {
					factura += ", ";
				}
			}
		}
		factura += "  $" + precio;
		return factura;
	}
	
	public int getPrecio() {
		int precio = 0;
		for (int i = 0; i < agregados.size(); i++) {
			precio += agregados.get(i).getCostoAdicional();
		}
		return precioBase + precio;
	}
	
	public void agregarIngrediente(Ingrediente ingrediente) {
		agregados.add(ingrediente);
	}
	
	public void eliminarIngrediente(Ingrediente ingrediente) {
		eliminados.add(ingrediente);
	}
}
