package modulo;

import java.util.ArrayList;

public class ProductoAjustado extends ProductoMenu implements Producto {
	
	private ProductoMenu base;
	
	private ArrayList<Ingrediente> agregados = new ArrayList<Ingrediente>();
	
	private ArrayList<Ingrediente> eliminados = new ArrayList<Ingrediente>();
	
	public ProductoAjustado(ProductoMenu base) {
		super(base.getNombre(),base.getPrecio(),base.getCalorias());
		this.base = base;
	}
	
	public String generarTextoFactura() {
		int precio = 0;
		String factura = nombre;
		precio += precioBase;
		if (agregados.size() > 0) {
			factura +=" con ";
			for (int i = 0; i < agregados.size(); i++) {
				factura += agregados.get(i).getNombre();
				precio += agregados.get(i).getCostoAdicional();
				if (i+1 < agregados.size()) {
					factura += ", ";
				}
			}
		}
		if (agregados.size()>0 && eliminados.size()>0) {
			factura += "; ";
		}
		if (eliminados.size() > 0) {
			factura +=" sin ";
			for (int i = 0; i < eliminados.size(); i++) {
				factura += eliminados.get(i).getNombre();
				if (i+1 < eliminados.size()) {
					factura += ", ";
				}
			}
		}
		factura += " Cal: "+ getCalorias();
		factura += "  $" + precio;
		return factura;
	}
	
	public int getPrecio() {
		int precio = 0;
		for (int i = 0; i < agregados.size(); i++) {
			precio += agregados.get(i).getCostoAdicional();
		}
		return precioBase + precio;
	}
	
	public int getCalorias() {
		int caloriaCambio = 0;
		for (int i = 0; i < agregados.size(); i++) {
			caloriaCambio += agregados.get(i).getCalorias();
		}
		for (int i = 0; i < eliminados.size(); i++) {
			caloriaCambio -= eliminados.get(i).getCalorias();
		}
		return calorias + caloriaCambio;
	}
	
	public boolean equals(ProductoAjustado producto) {
		boolean mismoProducto = true;
		if (!(base.getNombre() == producto.getNombre())) {
			mismoProducto = false;
		}
		else if (!(base.getPrecio() == producto.getPrecio())) {
			mismoProducto = false;
		}
		else if (!(base.getCalorias() == producto.getCalorias())) {
			mismoProducto = false;
		}
		else {
			ArrayList<Ingrediente> agregadosComp = producto.getAgregados();
			ArrayList<Ingrediente> eliminadosComp = producto.getEliminados();
			if (agregadosComp.size() != agregados.size() || eliminadosComp.size() != eliminados.size()) {
				mismoProducto = false;
			}
			else {
				int i=0;
				while (mismoProducto && i < agregadosComp.size()) {
					Ingrediente ingredienteComp = agregadosComp.get(i);
					boolean existe = false;
					for (int j=0; j < agregados.size(); j++) {
						if (agregados.get(i).getNombre() == ingredienteComp.getNombre()) {
							existe = true;
						}
					}
					if (!existe) {
						mismoProducto = false;
					}
					i++;
				}
				i = 0;
				while (mismoProducto && i < eliminadosComp.size()) {
					Ingrediente ingredienteComp = eliminadosComp.get(i);
					boolean existe = false;
					for (int j=0; j < eliminados.size(); j++) {
						if (eliminados.get(i).getNombre() == ingredienteComp.getNombre()) {
							existe = true;
						}
					}
					if (!existe) {
						mismoProducto = false;
					}
					i++;
				}
			}
		}
		
		return mismoProducto;
	}
	
	public ArrayList<Ingrediente> getAgregados() {
		return agregados;
	}
	
	public ArrayList<Ingrediente> getEliminados() {
		return eliminados;
	}
	
	public void agregarIngrediente(Ingrediente ingrediente) {
		agregados.add(ingrediente);
	}
	
	public void eliminarIngrediente(Ingrediente ingrediente) {
		eliminados.add(ingrediente);
	}
}
