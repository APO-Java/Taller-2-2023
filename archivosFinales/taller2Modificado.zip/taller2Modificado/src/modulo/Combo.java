package modulo;

import java.util.ArrayList;

public class Combo implements Producto {
	private double descuento;
	
	private String nombreCombo;
	
	private ArrayList<Producto> itemsCombo = new ArrayList<Producto>();
	
	public Combo(String nombre, double descuento) {
		this.descuento = descuento;
		nombreCombo = nombre;
	}
	
	public String getNombre() {
		return nombreCombo;
	}
	
	public void agregarItemCombo(Producto itemCombo) {
		itemsCombo.add(itemCombo);
	}
	
	public int getPrecio() {
		int precio = 0;
		for (int i = 0; i < itemsCombo.size(); i++) {
			precio += itemsCombo.get(i).getPrecio();
		}
		precio = (int) (precio*(1-descuento));
		return precio;
	}
	
	public int getCalorias() {
		int calorias = 0;
		for (int i = 0; i < itemsCombo.size(); i++) {
			calorias += itemsCombo.get(i).getCalorias();
		}
		return calorias;
	}
	
	public ArrayList<Producto> getItemsCombo() {
		return itemsCombo;
	}
	
	public String generarTextoFactura() {
		return nombreCombo + " Cal: "+ getCalorias()+ " $" + getPrecio();
	}
	
	public boolean equals(Producto producto) {
		boolean mismoProducto = true;
		if (!(producto.getNombre() == nombreCombo)) {
			mismoProducto = false;
		}
		return mismoProducto;
	}
}
