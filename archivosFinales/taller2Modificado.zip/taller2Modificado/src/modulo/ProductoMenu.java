package modulo;

public class ProductoMenu implements Producto {
	
	//Atributos
	protected String nombre;
	
	protected int precioBase;
	
	protected int calorias;
	
	//Métodos
	public ProductoMenu(String nombre, int precioBase, int calorias) {
		this.nombre = nombre;
		this.precioBase = precioBase;
		this.calorias = calorias;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public int getPrecio() {
		return precioBase;
	}
	
	public int getCalorias() {
		return calorias;
	}
	
	public String generarTextoFactura() {
		return nombre + " Cal: " + calorias+ "  $" + precioBase;
	}
	
	public boolean equals(Producto producto) {
		boolean mismoProducto = true;
		if (!(producto.getNombre() == nombre)) {
			mismoProducto = false;
		}
		return mismoProducto;
	}
	
}
